package identifier;
import org.junit.Test;
import org.junit.Rule;
import static org.junit.Assert.*;
import csbst.utils.ExceptionsFormatter;
import identifier.Identifier;
public class IdentifierLastTestCandidate {
  /** 
 * Chromosome :1)----->identifier.Identifier[]2)----->valid_f[\u0079] Covered Branches:[]
 */
  @Test public void TestCase() throws Throwable {
    Identifier clsUTIdentifier=null;
    try {
      clsUTIdentifier=new Identifier();
    }
 catch (    Throwable exce) {
      
    }
  }
}
