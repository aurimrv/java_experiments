package identifier;
import csbst.testing.fitness.*;
public class Identifier {
  public boolean validateIdentifier(  String s){
    NumberCoveredBranches.maintainPathTrace(1,"identifier.Identifier");
    char achar;
    boolean valid_id=false;
    if ((s != null) && (s.length() > 0)) {
      NumberCoveredBranches.maintainPathTrace(2,"identifier.Identifier");
      achar=s.charAt(0);
      valid_id=valid_s(achar);
      if (s.length() > 1) {
        NumberCoveredBranches.maintainPathTrace(4,"identifier.Identifier");
        achar=s.charAt(1);
        int i=1;
        while (i < s.length() - 1) {
          NumberCoveredBranches.maintainPathTrace(6,"identifier.Identifier");
          achar=s.charAt(i);
          if (!valid_f(achar)) {
            NumberCoveredBranches.maintainPathTrace(7,"identifier.Identifier");
            valid_id=false;
          }
 else {
            NumberCoveredBranches.maintainPathTrace(8,"identifier.Identifier");
          }
          i++;
        }
      }
 else {
        NumberCoveredBranches.maintainPathTrace(5,"identifier.Identifier");
      }
    }
 else {
      NumberCoveredBranches.maintainPathTrace(3,"identifier.Identifier");
    }
    if (valid_id && (s.length() >= 1) && (s.length() <= 6)) {
      NumberCoveredBranches.maintainPathTrace(9,"identifier.Identifier");
      return true;
    }
 else {
      NumberCoveredBranches.maintainPathTrace(10,"identifier.Identifier");
      return false;
    }
  }
  public boolean valid_s(  char ch){
    NumberCoveredBranches.maintainPathTrace(11,"identifier.Identifier");
    if (((ch >= 'A') && (ch <= 'Z')) || ((ch >= 'a') && (ch <= 'z'))) {
      NumberCoveredBranches.maintainPathTrace(12,"identifier.Identifier");
      return true;
    }
 else {
      NumberCoveredBranches.maintainPathTrace(13,"identifier.Identifier");
      return false;
    }
  }
  public boolean valid_f(  char ch){
    NumberCoveredBranches.maintainPathTrace(14,"identifier.Identifier");
    if (((ch >= 'A') && (ch <= 'Z')) || ((ch >= 'a') && (ch <= 'z')) || ((ch >= '0') && (ch <= '9'))) {
      NumberCoveredBranches.maintainPathTrace(15,"identifier.Identifier");
      return true;
    }
 else {
      NumberCoveredBranches.maintainPathTrace(16,"identifier.Identifier");
      return false;
    }
  }
}
