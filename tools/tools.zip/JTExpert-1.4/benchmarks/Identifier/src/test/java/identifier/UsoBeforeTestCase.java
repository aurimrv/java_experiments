package identifier;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class UsoBeforeTestCase {
  private Identifier id;
  
  @Before
  public void inicializa() {
      id = new Identifier();
  }
    
  @Test
  public void particaoValida() {
    boolean resultado = id.validateIdentifier("a1");
    assertEquals(true, resultado);      
  }

  @Test
  public void particaoInvalida01() {
    boolean resultado = id.validateIdentifier("");
    assertEquals(false, resultado);      
  }

  @Test
  public void particaoInvalida02() {
    boolean resultado = id.validateIdentifier("A1b2C3d");
    assertEquals(false, resultado);      
  }

  @Test
  public void particaoInvalida03() {
    boolean resultado = id.validateIdentifier("2B3");
    assertEquals(false, resultado);      
  }  

  @Test
  public void particaoInvalida04() {
    boolean resultado = id.validateIdentifier("Z#12");
    assertEquals(false, resultado);      
  }  
}