package identifier;

import org.junit.Test;
import static org.junit.Assert.*;

public class ParticionamentoTestCase {
  @Test
  public void particaoValida() {
    Identifier id = new Identifier();
    boolean resultado = id.validateIdentifier("a1");
    assertEquals(true, resultado);      
  }

  @Test
  public void particaoInvalida01() {
    Identifier id = new Identifier();
    boolean resultado = id.validateIdentifier("");
    assertEquals(false, resultado);      
  }

  @Test
  public void particaoInvalida02() {
    Identifier id = new Identifier();
    boolean resultado = id.validateIdentifier("A1b2C3d");
    assertEquals(false, resultado);      
  }

  @Test
  public void particaoInvalida03() {
    Identifier id = new Identifier();
    boolean resultado = id.validateIdentifier("2B3");
    assertEquals(false, resultado);      
  }  

  @Test
  public void particaoInvalida04() {
    Identifier id = new Identifier();
    boolean resultado = id.validateIdentifier("Z#12");
    assertEquals(false, resultado);      
  }  
}