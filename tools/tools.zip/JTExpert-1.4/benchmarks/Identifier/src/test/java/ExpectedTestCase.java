import org.junit.Test;

public class ExpectedTestCase {
  @Test(timeout=100,expected=IndexOutOfBoundsException.class)
  public void testeExcecao() {
      String str = "TesteJUnit";
      String result = str.substring(15);
  }
}