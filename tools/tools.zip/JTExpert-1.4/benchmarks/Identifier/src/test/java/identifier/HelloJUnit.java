package identifier;

import org.junit.Test;
import static org.junit.Assert.*;

public class HelloJUnit {
  @Test
  public void primeiroTeste() {
      Identifier id = new Identifier();
      boolean resultado = id.validateIdentifier("abc");
      assertEquals(true, resultado);
  }

  @Test
  public void segundoTeste() {
      Identifier id = new Identifier();
      boolean resultado = id.validateIdentifier("1de");
      assertEquals(false, resultado);
  } 
}
