package identifier;

import static org.junit.Assert.assertEquals;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import util.SpreadsheetData;

@RunWith(Parameterized.class)
public class XlsDataDrivenTestCase {

	private static final String XLS_FILENAME = "src/test/resources/data.xls";

	private static Identifier id = new Identifier();

	private String param;
	private boolean result;

	@Parameters
	public static Collection<?> data() throws IOException {
		InputStream spreadsheet = new FileInputStream(
				XlsDataDrivenTestCase.XLS_FILENAME);
		return new SpreadsheetData(spreadsheet).getData();
	}

	public XlsDataDrivenTestCase(String param, boolean result) {
		this.param = param;
		this.result = result;
	}

	@Test(timeout = 100)
	public void validate() {
		boolean value = id.validateIdentifier(param);
		assertEquals(result, value);
	}
}