package identifier;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
    HelloJUnit.class,
    ParticionamentoTestCase.class,
    TimeoutTestCase.class,
    UsoBeforeTestCase.class,
})
public class AllTests {}


