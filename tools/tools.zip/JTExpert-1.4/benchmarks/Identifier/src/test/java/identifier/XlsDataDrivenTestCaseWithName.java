package identifier;

import static org.junit.Assert.assertEquals;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import util.SpreadsheetData;

@RunWith(Parameterized.class)
public class XlsDataDrivenTestCaseWithName {

	private static final String XLS_FILENAME = 
			"src/test/resources/data-name.xls";

	private static Identifier id = new Identifier();

	private String param;
	private boolean result;

	@Parameters(name = "{index}: validateIdentifier({0})={1} - {2}")
	public static Collection<?> data() throws IOException {
		InputStream spreadsheet = new FileInputStream(
				XlsDataDrivenTestCaseWithName.XLS_FILENAME);
		return new SpreadsheetData(spreadsheet).getData();
	}

	public XlsDataDrivenTestCaseWithName(String param, boolean result,
			String desc) {
		this.param = param;
		this.result = result;
	}

	@Test(timeout = 100)
	public void validate() {
		boolean value = id.validateIdentifier(param);
		assertEquals(result, value);
	}
}
