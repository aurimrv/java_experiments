package identifier;
import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.Rule;
import identifier.Identifier;
/** 
 * This class was automatically generated to test the identifier.Identifier class according to all branches coverage criterion
ExceptionsOriented: false 
projectPackagesPrefix:identifier 
Covered branches: [1, 16, 3, 10, 11, 12, 13, 14, 15]
Uncovered branches: [2, 4, 5, 6, 7, 8, 9]
Total number of branches: 16
Total number of covered branches: 9
Coverage : 56,25%
Evaluations : 59870
search time (ms): 42501
total runtime (ms): 43906
 */
public class IdentifierJTETestCases_0_0 {
  /** 
 * Chromosome :1)----->identifier.Identifier[]2)----->valid_f[\u0072] Covered Branches:[14, 15]
 */
  @Test public void TestCase0() throws Throwable {
    Identifier clsUTIdentifier=null;
    try {
      clsUTIdentifier=new Identifier();
    }
 catch (    Throwable exce) {
      throw exce;
    }
    char clsUTIdentifierP2P1='\u0072';
    boolean clsUTIdentifierP2R=false;
    try {
      clsUTIdentifierP2R=clsUTIdentifier.valid_f(clsUTIdentifierP2P1);
    }
 catch (    Throwable exce) {
      throw exce;
    }
    assertEquals(true,clsUTIdentifierP2R);
  }
  /** 
 * Chromosome :1)----->identifier.Identifier[]2)----->valid_s[\u0026] Covered Branches:[11, 13]
 */
  @Test public void TestCase1() throws Throwable {
    Identifier clsUTIdentifier=null;
    try {
      clsUTIdentifier=new Identifier();
    }
 catch (    Throwable exce) {
      throw exce;
    }
    char clsUTIdentifierP2P1='\u0026';
    boolean clsUTIdentifierP2R=false;
    try {
      clsUTIdentifierP2R=clsUTIdentifier.valid_s(clsUTIdentifierP2P1);
    }
 catch (    Throwable exce) {
      throw exce;
    }
    assertEquals(false,clsUTIdentifierP2R);
  }
  /** 
 * Chromosome :1)----->identifier.Identifier[]2)----->validateIdentifier[String] Covered Branches:[1, 3, 10]
 */
  @Test public void TestCase2() throws Throwable {
    Identifier clsUTIdentifier=null;
    try {
      clsUTIdentifier=new Identifier();
    }
 catch (    Throwable exce) {
      throw exce;
    }
    boolean clsUTIdentifierP2R=false;
    try {
      clsUTIdentifierP2R=clsUTIdentifier.validateIdentifier((String)null);
    }
 catch (    Throwable exce) {
      throw exce;
    }
    assertEquals(false,clsUTIdentifierP2R);
  }
  /** 
 * Chromosome :1)----->identifier.Identifier[]2)----->valid_f[\u003b] Covered Branches:[16, 14]
 */
  @Test public void TestCase3() throws Throwable {
    Identifier clsUTIdentifier=null;
    try {
      clsUTIdentifier=new Identifier();
    }
 catch (    Throwable exce) {
      throw exce;
    }
    char clsUTIdentifierP2P1='\u003b';
    boolean clsUTIdentifierP2R=false;
    try {
      clsUTIdentifierP2R=clsUTIdentifier.valid_f(clsUTIdentifierP2P1);
    }
 catch (    Throwable exce) {
      throw exce;
    }
    assertEquals(false,clsUTIdentifierP2R);
  }
  /** 
 * Chromosome :1)----->identifier.Identifier[]2)----->valid_s[\u006c] Covered Branches:[11, 12]
 */
  @Test public void TestCase4() throws Throwable {
    Identifier clsUTIdentifier=null;
    try {
      clsUTIdentifier=new Identifier();
    }
 catch (    Throwable exce) {
      throw exce;
    }
    char clsUTIdentifierP2P1='\u006c';
    boolean clsUTIdentifierP2R=false;
    try {
      clsUTIdentifierP2R=clsUTIdentifier.valid_s(clsUTIdentifierP2P1);
    }
 catch (    Throwable exce) {
      throw exce;
    }
    assertEquals(true,clsUTIdentifierP2R);
  }
}
